package com.freenet.vpn

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import java.io.ByteArrayInputStream
import java.nio.charset.StandardCharsets
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var backend: GoBackend
    private lateinit var configBox: EditText
    private lateinit var status: TextView
    private lateinit var connectButton: Button
    private lateinit var importButton: Button
    private val prefs by lazy { getSharedPreferences("freenet_private", MODE_PRIVATE) }

    private val tunnel = object : Tunnel {
        override fun getName() = "FreeNet-NL"
        override fun onStateChange(newState: Tunnel.State) {
            runOnUiThread {
                status.text = if (newState == Tunnel.State.UP) {
                    "● Bağlı — WireGuard tüneli açık"
                } else {
                    "○ Bağlı değil"
                }
                connectButton.text = if (newState == Tunnel.State.UP) "BAĞLANTIYI KES" else "HOLLANDA'YA BAĞLAN"
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        backend = GoBackend(applicationContext)
        buildUi()
        val saved = prefs.getString("wg_config", "") ?: ""
        if (saved.isNotBlank()) configBox.setText(saved)
        refreshState()
    }

    private fun buildUi() {
        val bg = 0xFF10111B.toInt()
        val panel = 0xFF1B1D2B.toInt()
        val white = 0xFFF4F4FA.toInt()
        val muted = 0xFFB7B9CA.toInt()
        val purple = 0xFF8B6CFF.toInt()

        val scroll = ScrollView(this)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 42, 24, 28)
            setBackgroundColor(bg)
        }
        scroll.addView(page)
        setContentView(scroll)

        page.addView(TextView(this).apply {
            text = "FreeNet VPN"
            textSize = 30f
            setTextColor(white)
            gravity = Gravity.CENTER
        })
        page.addView(TextView(this).apply {
            text = "KİŞİSEL • WIREGUARD • HOLLANDA"
            textSize = 12f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 26)
        })

        val country = TextView(this).apply {
            text = "🇳🇱   HOLLANDA SUNUCUSU"
            textSize = 19f
            setTextColor(white)
            gravity = Gravity.CENTER
            setPadding(12, 24, 12, 24)
            setBackgroundColor(panel)
        }
        page.addView(country)

        status = TextView(this).apply {
            text = "○ Bağlı değil"
            textSize = 16f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(8, 24, 8, 16)
        }
        page.addView(status)

        connectButton = Button(this).apply {
            text = "HOLLANDA'YA BAĞLAN"
            setTextColor(white)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(purple))
            setOnClickListener { onConnectClick() }
        }
        page.addView(connectButton)

        importButton = Button(this).apply {
            text = "SUNUCU YAPILANDIRMASI YÜKLE (.CONF)"
            setOnClickListener {
                val pick = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "text/*"
                }
                startActivityForResult(pick, REQUEST_CONFIG)
            }
        }
        page.addView(importButton)

        page.addView(TextView(this).apply {
            text = "WireGuard yapılandırması"
            textSize = 14f
            setTextColor(white)
            setPadding(0, 20, 0, 8)
        })

        configBox = EditText(this).apply {
            hint = "[Interface] ve [Peer] içeren .conf metnini buraya yapıştır"
            setHintTextColor(muted)
            setTextColor(white)
            textSize = 12f
            gravity = Gravity.TOP
            minLines = 8
            maxLines = 14
            setPadding(12, 12, 12, 12)
            setBackgroundColor(panel)
        }
        page.addView(configBox)

        val save = Button(this).apply {
            text = "YAPILANDIRMAYI KAYDET"
            setOnClickListener { saveConfig() }
        }
        page.addView(save)

        page.addView(TextView(this).apply {
            text = "Not: Bu uygulama kendi kiraladığın Hollanda VPS sunucusuna bağlanır. Sunucu kurulmadan ve geçerli .conf dosyası yüklenmeden bağlantı kurulamaz. VPN kullanımı internet sağlayıcına ve yerel mevzuata tabidir."
            textSize = 12f
            setTextColor(muted)
            setPadding(2, 22, 2, 4)
        })
    }

    private fun onConnectClick() {
        val current = try {
            backend.getState(tunnel)
        } catch (_: Exception) { Tunnel.State.DOWN }

        if (current == Tunnel.State.UP) {
            executor.execute {
                try {
                    backend.setState(tunnel, Tunnel.State.DOWN, null)
                    runOnUiThread { status.text = "○ Bağlantı kesildi" }
                } catch (e: Exception) {
                    showError("Bağlantı kesilemedi: ${e.message}")
                }
            }
            return
        }

        val raw = configBox.text.toString().trim()
        if (raw.isBlank()) {
            status.text = "Önce Hollanda sunucusunun .conf dosyasını yükle."
            return
        }
        prefs.edit().putString("wg_config", raw).apply()

        val permissionIntent = VpnService.prepare(this)
        if (permissionIntent != null) {
            startActivityForResult(permissionIntent, REQUEST_VPN_PERMISSION)
        } else {
            connectWithConfig(raw)
        }
    }

    private fun connectWithConfig(raw: String) {
        status.text = "Bağlanılıyor…"
        executor.execute {
            try {
                val config = Config.parse(
                    ByteArrayInputStream(raw.toByteArray(StandardCharsets.UTF_8))
                )
                backend.setState(tunnel, Tunnel.State.UP, config)
                runOnUiThread { status.text = "● Tünel açıldı — IP kontrolü yapılıyor…" }
            } catch (e: Exception) {
                showError("Bağlantı kurulamadı: ${e.message}")
            }
        }
    }

    private fun saveConfig() {
        val raw = configBox.text.toString().trim()
        if (!raw.contains("[Interface]") || !raw.contains("[Peer]")) {
            status.text = "Geçersiz yapılandırma: [Interface] ve [Peer] bölümleri gerekli."
            return
        }
        try {
            Config.parse(ByteArrayInputStream(raw.toByteArray(StandardCharsets.UTF_8)))
            prefs.edit().putString("wg_config", raw).apply()
            status.text = "Yapılandırma bu cihazda kaydedildi."
        } catch (e: Exception) {
            status.text = "Yapılandırma hatası: ${e.message}"
        }
    }

    @Deprecated("Legacy file picker callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        when (requestCode) {
            REQUEST_CONFIG -> {
                val uri = data?.data ?: return
                try {
                    contentResolver.openInputStream(uri)?.bufferedReader()?.use {
                        configBox.setText(it.readText())
                        saveConfig()
                    }
                } catch (e: Exception) {
                    status.text = "Dosya okunamadı: ${e.message}"
                }
            }
            REQUEST_VPN_PERMISSION -> {
                if (resultCode == RESULT_OK) connectWithConfig(configBox.text.toString().trim())
                else status.text = "Android VPN izni verilmedi."
            }
        }
    }

    private fun refreshState() {
        try {
            val up = backend.getState(tunnel) == Tunnel.State.UP
            status.text = if (up) "● Bağlı — WireGuard tüneli açık" else "○ Bağlı değil"
            connectButton.text = if (up) "BAĞLANTIYI KES" else "HOLLANDA'YA BAĞLAN"
        } catch (_: Exception) {}
    }

    private fun showError(message: String) {
        runOnUiThread { status.text = message }
    }

    override fun onDestroy() {
        executor.shutdown()
        super.onDestroy()
    }

    companion object {
        private const val REQUEST_CONFIG = 1001
        private const val REQUEST_VPN_PERMISSION = 1002
    }
}
