#!/usr/bin/env bash
set -euo pipefail

# Run as root on a fresh Ubuntu 22.04/24.04 VPS located in the Netherlands.
if [[ "${EUID}" -ne 0 ]]; then
  echo "Run as root: sudo bash setup-freenet.sh" >&2
  exit 1
fi

export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y wireguard iptables curl qrencode

WAN_IF="$(ip -4 route list default | awk '{print $5; exit}')"
if [[ -z "${WAN_IF}" ]]; then
  echo "Could not detect the VPS public network interface." >&2
  exit 1
fi

SERVER_PUBLIC_IP="$(curl -4fsS --max-time 10 https://api.ipify.org)"
SERVER_PRIVATE_KEY="$(wg genkey)"
SERVER_PUBLIC_KEY="$(printf '%s' "$SERVER_PRIVATE_KEY" | wg pubkey)"
CLIENT_PRIVATE_KEY="$(wg genkey)"
CLIENT_PUBLIC_KEY="$(printf '%s' "$CLIENT_PRIVATE_KEY" | wg pubkey)"

install -d -m 700 /etc/wireguard
umask 077

cat > /etc/wireguard/wg0.conf <<EOF
[Interface]
Address = 10.66.66.1/24
ListenPort = 51820
PrivateKey = ${SERVER_PRIVATE_KEY}
SaveConfig = false
PostUp = iptables -A FORWARD -i wg0 -j ACCEPT; iptables -A FORWARD -o wg0 -j ACCEPT; iptables -t nat -A POSTROUTING -o ${WAN_IF} -j MASQUERADE
PostDown = iptables -D FORWARD -i wg0 -j ACCEPT; iptables -D FORWARD -o wg0 -j ACCEPT; iptables -t nat -D POSTROUTING -o ${WAN_IF} -j MASQUERADE

[Peer]
PublicKey = ${CLIENT_PUBLIC_KEY}
AllowedIPs = 10.66.66.2/32
EOF
chmod 600 /etc/wireguard/wg0.conf

cat >/etc/sysctl.d/99-freenet-wireguard.conf <<'EOF'
net.ipv4.ip_forward=1
EOF
sysctl --system >/dev/null

if command -v ufw >/dev/null 2>&1 && ufw status | grep -q "Status: active"; then
  ufw allow 51820/udp
fi

cat > /root/freenet-nl.conf <<EOF
[Interface]
PrivateKey = ${CLIENT_PRIVATE_KEY}
Address = 10.66.66.2/32
DNS = 1.1.1.1

[Peer]
PublicKey = ${SERVER_PUBLIC_KEY}
Endpoint = ${SERVER_PUBLIC_IP}:51820
AllowedIPs = 0.0.0.0/0
PersistentKeepalive = 25
EOF
chmod 600 /root/freenet-nl.conf

systemctl enable --now wg-quick@wg0

echo
echo "FreeNet Hollanda WireGuard sunucusu kuruldu."
echo "Sunucu IP: ${SERVER_PUBLIC_IP}"
echo "UDP port: 51820"
echo "İstemci yapılandırması: /root/freenet-nl.conf"
echo
echo "ÖNEMLİ: VPS sağlayıcının güvenlik duvarında 51820/UDP portunu da aç."
echo "İstemci dosyasını güvenli şekilde Android telefona aktar; özel anahtar içerir."
if command -v qrencode >/dev/null 2>&1; then
  echo "QR kod (terminalde):"
  qrencode -t ansiutf8 < /root/freenet-nl.conf
fi
