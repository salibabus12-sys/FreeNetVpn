# FreeNet VPN — Android + Hollanda WireGuard sunucusu

Bu paket bir **Android Studio proje kaynak kodudur**; önceden derlenmiş APK değildir.
APK oluşturmak için Android Studio ve Android SDK gerekir. Uygulama, kendi Hollanda VPS
sunucuna WireGuard tüneli açar. Sunucu barındırma ücreti bu pakete dahil değildir.

## 1) Hollanda sunucusunu hazırla

1. Hollanda lokasyonlu bir VPS kirala (Ubuntu 22.04 veya 24.04, root/sudo erişimi).
2. VPS sağlayıcısının ağ güvenlik duvarında **UDP 51820** portuna izin ver.
3. `server/setup-freenet.sh` dosyasını VPS'ye güvenli biçimde aktar.
4. VPS üzerinde çalıştır:

   ```bash
   sudo bash setup-freenet.sh
   ```

5. Betik `/root/freenet-nl.conf` dosyasını üretir. Bu dosya özel anahtar içerir;
   kimseyle paylaşma, herkese açık yere yükleme. Yalnızca kendi telefonuna aktar.

> Betik IPv4 çıkışını NAT ile yönlendirir. VPS sağlayıcında UDP/51820 ve IP forwarding
> desteklenmelidir. Bazı bulut sağlayıcılarında ek firewall/security-group kuralı gerekir.

## 2) Android APK oluştur

1. Android Studio'yu bilgisayara kur.
2. Bu klasörü Android Studio ile **Open** seçerek aç.
3. JDK 17 ve Android SDK 36 kurulu olsun.
4. Gradle senkronizasyonunun tamamlanmasını bekle.
5. **Build > Build Bundle(s) / APK(s) > Build APK(s)** seç.
6. APK genellikle `app/build/outputs/apk/debug/app-debug.apk` konumuna çıkar.

Komut satırıyla (Gradle 8.11.1 ve JDK 17 kuruluysa):

```bash
gradle assembleDebug
```

## 3) Telefonda bağlan

1. FreeNet VPN APK'sını Android telefona yükle.
2. Uygulamayı aç, **SUNUCU YAPILANDIRMASI YÜKLE (.CONF)** düğmesine dokun.
3. VPS'den aldığın `freenet-nl.conf` dosyasını seç.
4. **HOLLANDA'YA BAĞLAN** düğmesine dokun ve Android VPN iznini onayla.
5. Çıkış IP'sini bir IP kontrol sitesinden doğrula; Hollanda görünmelidir.

## Güvenlik

- Yapılandırma dosyası özel anahtar içerir. E-posta/grup/sohbet üzerinden paylaşma.
- Bu ilk sürüm tek istemci yapılandırması üretir. İkinci cihaz için ayrı anahtar/peer oluştur.
- Uygulama trafiği kendi VPS sunucundan geçirir; VPS sağlayıcısı ve hedef siteler yine trafik metaverisini görebilir.
- VPN, her tür ağ engelini aşmayı garanti etmez; sosyal medya platformlarının hesap/yaş kurallarını değiştirmez.
- VPN kullanımı bulunduğun yerdeki mevzuata ve hizmet koşullarına uygun olmalıdır.

## Teknik not

Android tarafında WireGuard'ın resmi embeddable tunnel kütüphanesi kullanılır:
`com.wireguard.android:tunnel:1.0.20260102` (Maven Central, Apache-2.0).
Uygulama gerçek tünel oluşturur; yalnızca DNS değiştirici veya sahte bağlantı ekranı değildir.
